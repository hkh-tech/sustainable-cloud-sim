
# Changelog

## 2025-10-27
- Added multiple policies: carbon_greedy, round_robin, random, carbon_latency_weighted
- Introduced non-linear utilization-aware power model
- Added CLI flags: --policy, --max-wait
- Recorded queue wait time per task
- Added experiment runner script
- Revised README for validation, limitations, and sober tone
